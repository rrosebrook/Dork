Read Me
=======

zork but different

* Free software: MIT license
* Documentation:


Features
--------

* TODO

Credits
-------

Please see the credits provided in the repo or Documentation.


This package was created with Cookiecutter_ and the
`lsmith-zenoscave/cookiecutter-simplemodule`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`lsmith-zenoscave/cookiecutter-simplemodule`: https://github.com/lsmith-zenoscave/cookiecutter-simplemodule
