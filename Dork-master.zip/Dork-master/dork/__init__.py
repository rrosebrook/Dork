# -*- coding: utf-8 -*-
"""Dork Game main module.
"""

__version__ = '0.1.0'
__author__ = ", ".join([
    "Luke Smith",
])
