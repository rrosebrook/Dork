#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Dork Game main run-script.
"""
import sys
from dork.cli import main

main(*sys.argv)
